We're glad that you chose our bootstrap theme. 

If you want to be notified about updates and new versions leave us your e-mail: http://bootstrapmaster.com/newsletter/ or follow us on Twitter http://twitter.com/BootstrapMaster

You can also download our free bootstrap themes: http://bootstrapmaster.com/free-themes/

If you have questions or you need our help you can find us here: http://bootstrapmaster.com/contact/

Try for free our latest project http://brix.io - Interface Builder for Bootstrap Framework
