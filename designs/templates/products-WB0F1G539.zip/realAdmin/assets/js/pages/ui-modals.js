$(document).ready(function() {
   
	//Declare begin
   	$('.md-trigger').modalEffects();
   //Declare end

});