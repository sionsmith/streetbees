$(document).ready(function(){
	/* ---------- Datable ---------- */
	$('.datatable').dataTable();
});